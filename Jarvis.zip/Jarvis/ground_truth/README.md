This directoy contains the ground truth data fro micro-benchmark and macro-benchmark.

* For micro-benchmark, we have provided the ground truth of 135 testing programs in each subdirectories in `micro-benchmark.md`, denoted as `callgraph.json`

* For macro-benchmark, we have provided the ground truth call graphs for the six projects,  denoted as `EA.json`, `DA.json`, `DW.json`

  

