# def func():
#     pass
from from_module_2 import func
