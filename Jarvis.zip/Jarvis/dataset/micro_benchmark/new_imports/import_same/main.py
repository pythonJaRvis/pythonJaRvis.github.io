from from_module_1 import func
from from_module_2 import func

func()
