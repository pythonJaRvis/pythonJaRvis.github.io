from from_module_1 import func1 as func
from from_module_2 import func2 as func

func()
