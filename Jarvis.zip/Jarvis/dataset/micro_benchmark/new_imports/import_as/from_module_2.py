def func2():
    pass
