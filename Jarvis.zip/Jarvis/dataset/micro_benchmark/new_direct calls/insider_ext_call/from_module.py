def ext_change(c, fn):
    c.fn = fn
