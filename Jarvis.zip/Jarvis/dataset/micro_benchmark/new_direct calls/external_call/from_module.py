def func1():
    pass


def change(c):
    c.fn = func1
