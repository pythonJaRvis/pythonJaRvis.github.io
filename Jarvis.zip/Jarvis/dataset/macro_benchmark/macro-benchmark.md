The projects for the macro-benchmark can be retrieved via the following links. Note that we used the corresponding commits when we cloned the repository.



## 1. boytop

GitHub repo url: [https://github.com/aristocratos/bpytop/](https://github.com/aristocratos/bpytop/)

commit: ac0f6660be0ad87b23ecb7f371a4a737e1bf017f

## 2. sqlparse

GitHub: https://github.com/andialbrecht/sqlparse

commit: 9f44d54c07180b826a6276d3acf5e1458b507c3f

## 3. TextRank-4ZH

GitHub: https://github.com/letiantian/TextRank4ZH

commit: 3c475a442ca187e90a1d1afaa89d312cb9017c7

## 4. furl

GitHub: https://github.com/gruns/furl

commit:774846234ff803606fdd289a7549f9b50b2b3677

## 5. rich-cli

GitHub: https://github.com/Textualize/rich-cli

commit:  0721cb196661687d8ecd9af4baf48576b240c978

## 6. sshtunnel

GitHub: https://github.com/pahaz/sshtunnel

commit:d2167a235bf67c24c77786ddbd81e0dca2baec63











