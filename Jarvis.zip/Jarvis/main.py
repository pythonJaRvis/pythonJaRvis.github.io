# Copyright [pythonJaRvis] [name of copyright owner]
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import time
import formats
from pythoncg import CallGraphGenerator
from utils.constants import CALL_GRAPH_OP, KEY_ERR_OP
import json


def main():
    start_time = time.time()

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "entry_point",
        nargs="*",
        help="Entry points to be processed",
    )
    parser.add_argument(
        "--package",
        help="Package containing the code to be analyzed",
        default=None,
    )
    parser.add_argument(
        "--fasten",
        help="Produce call graph using the FASTEN format",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--product",
        help="Package name",
        default="",
    )
    parser.add_argument(
        "--forge",
        help="Source the product was downloaded from",
        default="",
    )
    parser.add_argument(
        "--version",
        help="Version of the product",
        default="",
    )
    parser.add_argument(
        "--timestamp",
        help="Timestamp of the package's version",
        default=0,
    )
    parser.add_argument(
        "--max-iter",
        type=int,
        help=(
            "Maximum number of iterations through source code. "
            + "If not specified a fix-point iteration will be performed."
        ),
        default=-1,
    )
    parser.add_argument(
        "--demand-ratios",
        type=int,
        default=0,
    )
    parser.add_argument(
        "--decy",
        action="store_true",
        help="whether iterate the dependency",
        default=False,
    )
    parser.add_argument(
        "--moduleEntry",
        nargs="*",
        help="whether make main as entry",
        default=None,
    )
    parser.add_argument(
        "--operation",
        type=str,
        choices=[CALL_GRAPH_OP, KEY_ERR_OP],
        help=(
            "Operation to perform. "
            + f"Choose {CALL_GRAPH_OP} for call graph generation (default)"
            + f" or {KEY_ERR_OP} for key error detection on dictionaries."
        ),
        default=CALL_GRAPH_OP,
    )

    parser.add_argument(
        "--as-graph-output",
        help="Output for the assignment graph",
        default=None,
    )
    parser.add_argument(
        "-o",
        "--output",
        help="Output path",
        default=None,
    )
    args = parser.parse_args()

    cg = CallGraphGenerator(
        args.entry_point,
        args.package,
        args.max_iter,
        args.operation,
        decy=args.decy,
        moduleEntry=args.moduleEntry,
        demand_ratios=args.demand_ratios,
    )
    cg.analyze()

    formatter = formats.Fasten(
        cg, "", args.product, args.forge, args.version, args.timestamp
    )
    if args.operation == CALL_GRAPH_OP:
        if args.fasten:
            formatter = formats.Fasten(
                cg, args.package, args.product, args.forge, args.version, args.timestamp
            )
        else:
            formatter = formats.Simple(cg)
        output = formatter.generate()
    else:
        output = cg.output_key_errs()
    output = formatter.generate()
    as_formatter = formats.AsGraph(cg)

    if args.output:
        with open(args.output, "w+") as f:
            f.write(json.dumps(output))
    else:
        print(json.dumps(output))
    if args.as_graph_output:
        with open(args.as_graph_output, "w+") as f:
            f.write(json.dumps(as_formatter.generate()))


if __name__ == "__main__":
    main()
